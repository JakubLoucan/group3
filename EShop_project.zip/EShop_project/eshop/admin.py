from django.contrib import admin
from eshop import models

admin.site.register(models.Kategorie)
admin.site.register(models.Znacka)
admin.site.register(models.Produkt)
admin.site.register(models.Cena)